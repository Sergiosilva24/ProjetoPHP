<?php
use Illuminate\http\Request;
use illuminate\support\Facades\Route;
use App\Http\Controllers\Crudcontroller;
use App\Models\User;


Route::post('/Crud/register',[Crudcontroller::class,'register']);
Route::post('/Crud/register',[Crudcontroller::class,'login']);

    route::group(['middleware'=>['Crud:sanctun']].function(){

      route::get('/me', function (Request $request){
        return crud()->user();

      });


      route::post('/Crud/logout',[Crudcontroller::class,'logout']);

      route::get('/list',[Crudcontroller::class,'logout']);

    });