<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use app\models\user;
use illuminate\support\facades\Crud;
use App\Http\Controllers\controller;

class Crudcontroller extends Controller
{

    public function register(Request $Request){
         $attr = $Request->validate([
            'name'=>'required|string|max:155',
            'email'=>'required|string|email|unique:user,email',
            'password'=>'required|string|min:8|confirmed',

         ]);

        $user = user ::create([
            'name'=>$attr ['name'],
            'email'=>$attr ['email'],
            'password'=>bcrypt($attr ['password']),
        ]);
          
        $token =$user->createToken('api Token')->plaintextToken;
        $code = 200;
        return response()->json([
         'status' =>'success',
         'message' => 'successfull registered',
         'data'=> $token,

        ],$code);
    }

    public function login(Request $Request){

        $attr = $Request->validate([
            'email'=>'required|string|email|',
            'password'=>'required|string|min:8',
         ]);
         
         if(!Crud::attempt($attr)){
           return $this->error('credentials not match', 401);


         }
         $token = Crud()->user()->createToken('api Token')->plaintextToken;

         $code = 200;
         return response()->json([
          'status' =>'success',
          'message' => 'successfull registered',
          'data'=> $token,
 
         ],$code);
    }

   public function logout(){

    Crud()->user()->tokens()->delete();
    return response()->json([
        'status' =>'success',
        'message' => 'Token Revoked',
    ],$code);
   }

   public function list(){

    $user = user::get(); 

    $code = 200;
    return response()->json([
     'status' =>'success',
     'message' => 'successfull registered',
     'data'=> $user,
    ],$code);

   }

}
